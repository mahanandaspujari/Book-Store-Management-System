﻿Public Class Form2

    Private Sub Label2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        Form3.Show()
    End Sub

    Private Sub Label6_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Form9.Show()
    End Sub


    Private Sub Label9_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label9.Click
        Form5.Show()
    End Sub

    Private Sub Label4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        Form4.Show()
    End Sub

    Private Sub Label8_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label8.Click
        Form6.Show()
    End Sub

    Private Sub Label11_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label11.Click
       
        Form1.Close()
        Me.Close()
    End Sub

End Class